from django.apps import AppConfig


class ZeusConfig(AppConfig):
    name = 'Zeus'
